<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['kontak'])) {
    $_SESSION['kontak'] = []; 
}

$kontak = $_SESSION['kontak'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Kontak</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    body {
        background: #081522;
        padding: 40px;
        color: #e9f4ff;
    }

    h1 {
        text-align: center;
        font-size: 32px;
        color: #76c8ff;
        text-shadow: 0 0 12px rgba(0, 150, 255, 0.5);
        margin-bottom: 30px;
    }

    .top-buttons {
        display: flex;
        justify-content: space-between;
        max-width: 1000px;
        margin: auto;
        margin-bottom: 20px;
    }

    .btn-small {
        padding: 10px 16px;
        background: rgba(0, 150, 255, 0.15);
        color: #aee1ff;
        border-radius: 10px;
        font-weight: 600;
        text-decoration: none;
        border: 1px solid rgba(0, 150, 255, 0.35);
        backdrop-filter: blur(6px);
        transition: 0.25s;
    }

    .btn-small:hover {
        background: rgba(0, 180, 255, 0.3);
        box-shadow: 0 0 12px rgba(0,180,255,0.6);
        transform: translateY(-2px);
    }

    .wrapper {
        max-width: 1000px;
        margin: auto;
        background: rgba(16, 40, 70, 0.4);
        padding: 25px 30px;
        border-radius: 18px;
        backdrop-filter: blur(6px);
        box-shadow: 0 0 25px rgba(0, 140, 255, 0.25);
        border: 1px solid rgba(0, 150, 255, 0.25);
    }

    .btn {
        padding: 12px 20px;
        background: linear-gradient(135deg, #009dff, #00d0ff);
        color: white;
        border-radius: 12px;
        font-weight: 600;
        text-decoration: none;
        box-shadow: 0 0 12px rgba(0, 150, 255, 0.5);
        transition: 0.25s;
    }

    .btn:hover {
        box-shadow: 0 0 20px rgba(0, 180, 255, 0.75);
        transform: translateY(-2px);
    }

    table {
        width: 100%;
        margin-top: 25px;
        border-collapse: collapse;
        background: rgba(20, 50, 80, 0.6);
        border-radius: 12px;
        overflow: hidden;
        backdrop-filter: blur(6px);
    }

    th {
        background: rgba(18, 45, 75, 0.9);
        padding: 14px;
        font-size: 15px;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        border-bottom: 1px solid rgba(255,255,255,0.12);
    }

    td {
        padding: 12px 14px;
        border-bottom: 1px solid rgba(255,255,255,0.08);
        font-size: 14px;
    }

    tr:hover {
        background: rgba(255, 255, 255, 0.06);
        transition: 0.2s;
    }

    .actions a {
        color: #5ecbff;
        font-weight: 600;
        text-decoration: none;
        margin-right: 12px;
        transition: 0.2s;
    }

    .actions a:hover {
        color: #9be3ff;
        text-shadow: 0 0 6px rgba(0,180,255,0.7);
    }

    .empty {
        margin-top: 30px;
        text-align: center;
        font-size: 16px;
        opacity: 0.85;
    }
</style>

</head>

<body>

<div class="top-buttons">
    <a href="login.php" class="btn-small">⟵ Logout</a>
</div>

<h1>📇 Manajemen Kontak</h1>

<div class="wrapper">

    <div style="text-align: right; margin-bottom: 10px;">
        <a href="add_kontak.php" class="btn">+ Tambah Kontak</a>
    </div>

    <?php if (empty($kontak)): ?>

        <p class="empty">Belum ada kontak tersimpan. Klik tombol "Tambah Kontak".</p>

    <?php else: ?>

        <table>
            <tr>
                <th>Nama</th>
                <th>Nomor</th>
                <th>Email</th>
                <th style="width: 150px;">Aksi</th>
            </tr>

            <?php foreach ($kontak as $index => $k): ?>
            <tr>
                <td><?= htmlspecialchars($k['nama']) ?></td>
                <td><?= htmlspecialchars($k['telepon']) ?></td>
                <td><?= htmlspecialchars($k['email']) ?></td>
                <td class="actions">
                    <a href="edit_kontak.php?id=<?= $index ?>">Edit</a>
                    <a href="delete_kontak.php?id=<?= $index ?>" onclick="return confirm('Hapus kontak ini?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>

    <?php endif; ?>

</div>

</body>
</html>
