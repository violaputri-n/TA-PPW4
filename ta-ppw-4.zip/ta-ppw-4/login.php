<?php
session_start();

$valid_username = "piolaja";
$valid_password = "piolcantik";

$login_error = "";

if (isset($_POST['login'])) {

    $username = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username === $valid_username && $password === $valid_password) {
        $_SESSION['login'] = true;   
        $_SESSION['username'] = $username;

        header("Location: dashboard_kontak.php");
        exit();
    } else {
        $login_error = "Username atau password salah!";
    }
}

if (isset($_SESSION['login']) && $_SESSION['login']) {
    header("Location: dashboard_kontak.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manajemen Kontak</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    body {
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;

        background-image: url("https://tse2.mm.bing.net/th/id/OIP.5li8Kx2HG1ZVcka3W19vXAHaEn?pid=ImgDet&w=178&h=110&c=7&dpr=1,5&o=7&rm=3");
        background-size: cover;
        background-position: center;
        background-attachment: fixed;

        position: relative;
        overflow: hidden;
    }

    body::before {
        content: "";
        position: absolute;
        inset: 0;
        background: rgba(0, 20, 40, 0.75);
        backdrop-filter: blur(3px);
        z-index: 0;
    }

    .login-container {
        position: relative;
        z-index: 2;
        width: 380px;
        background: #0c1c36;
        padding: 35px 40px;
        border-radius: 20px;
        box-shadow: 0 0 25px rgba(0, 150, 255, 0.35);
        border: 2px solid rgba(0, 140, 255, 0.35);
    }

    .login-container h2 {
        text-align: center;
        font-size: 25px;
        font-weight: 600;
        margin-bottom: 25px;
        color: #e9f3ff;
        text-shadow: 0 0 6px rgba(0, 180, 255, 0.6);
    }

    .error {
        background: #e63946;
        padding: 10px;
        border-radius: 8px;
        text-align: center;
        margin-bottom: 15px;
        color: white;
        font-weight: 600;
    }

    .form-group {
        margin-bottom: 17px;
    }

    label {
        display: block;
        font-size: 14px;
        margin-bottom: 6px;
        color: #c7e1ff;
    }

    input {
        width: 100%;
        padding: 12px;
        border-radius: 10px;
        border: 1px solid #5ea8ff;
        background: #0f2a4d;
        color: white;
        font-size: 14px;
        outline: none;
        transition: 0.2s;
    }

    input:focus {
        border-color: #00a6ff;
        box-shadow: 0 0 8px rgba(0, 166, 255, 0.7);
    }

    button {
        width: 100%;
        padding: 12px;
        margin-top: 10px;
        border: none;
        background: linear-gradient(135deg, #008cff, #00d0ff);
        color: white;
        font-size: 16px;
        font-weight: 600;
        border-radius: 12px;
        cursor: pointer;
        transition: 0.25s;
        box-shadow: 0 0 18px rgba(0, 170, 255, 0.4);
    }

    button:hover {
        transform: translateY(-2px);
        box-shadow: 0 0 25px rgba(0, 200, 255, 0.7);
    }

</style>
</head>

<body>

<div class="login-container">
    <h2>Manajemen Kontak</h2>

    <?php if ($login_error): ?>
        <div class="error"><?= $login_error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="email" placeholder="Masukkan username" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Masukkan password" required>
        </div>

        <button type="submit" name="login">Masuk</button>
    </form>
</div>

</body>
</html>
