<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['kontak'])) {
    $_SESSION['kontak'] = [];
}

$error = "";

if (isset($_POST['save'])) {

    $nama = trim($_POST['nama']);
    $telepon = trim($_POST['telepon']);
    $email = trim($_POST['email']);

    if (!preg_match("/^[a-zA-Z\s]+$/", $nama)) {
        $error = "Nama hanya boleh berisi huruf dan spasi.";
    } elseif (!preg_match("/^[0-9]{8,15}$/", $telepon)) {
        $error = "Nomor telepon hanya boleh angka dan minimal 8 digit.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid.";
    } else {
        $new = [
            "nama" => $nama,
            "telepon" => $telepon,
            "email" => $email
        ];

        $_SESSION['kontak'][] = $new;

        header("Location: dashboard_kontak.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Kontak</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    body {
        background: #081522;
        color: #e9f4ff;
        padding: 40px;
        display: flex;
        justify-content: center;
    }

    .container {
        width: 450px;
        background: rgba(15, 35, 60, 0.55);
        backdrop-filter: blur(8px);
        padding: 30px 35px;
        border-radius: 20px;
        border: 1px solid rgba(0, 150, 255, 0.25);
        box-shadow: 0 0 25px rgba(0,150,255,0.35);
        animation: fadeIn 0.4s ease;
    }

    h2 {
        text-align: center;
        margin-bottom: 25px;
        color: #76c8ff;
        text-shadow: 0 0 10px rgba(0,160,255,0.7);
    }

    .error {
        background: rgba(255, 60, 60, 0.25);
        border: 1px solid rgba(255, 80, 80, 0.5);
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 10px;
        color: #ff9f9f;
        text-align: center;
        font-size: 14px;
    }

    label {
        display: block;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 6px;
    }

    input {
        width: 100%;
        padding: 12px;
        border-radius: 12px;
        border: 1px solid rgba(90,170,255,0.4);
        background: rgba(255,255,255,0.07);
        color: #e9f4ff;
        font-size: 14px;
        margin-bottom: 18px;
        transition: 0.25s;
    }

    input:focus {
        border-color: #00baff;
        box-shadow: 0 0 12px rgba(0,160,255,0.9);
        outline: none;
    }

    button {
        width: 100%;
        padding: 12px;
        background: linear-gradient(135deg, #009dff, #00d0ff);
        border: none;
        color: white;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.25s;
        box-shadow: 0 0 18px rgba(0,160,255,0.5);
    }

    button:hover {
        box-shadow: 0 0 28px rgba(0,200,255,0.8);
        transform: translateY(-2px);
    }

    .back {
        display: inline-block;
        margin-top: 18px;
        text-align: center;
        width: 100%;
        color: #8cd7ff;
        text-decoration: none;
        font-weight: 500;
        transition: 0.2s;
    }

    .back:hover {
        color: #baf0ff;
        text-shadow: 0 0 8px rgba(0,180,255,0.8);
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<script>
function validateForm() {
    let nama = document.forms["form"]["nama"].value;
    let telp = document.forms["form"]["telepon"].value;
    let email = document.forms["form"]["email"].value;

    let nameRegex = /^[a-zA-Z\s]+$/;
    let telpRegex = /^[0-9]{8,15}$/;

    if (!nameRegex.test(nama)) {
        alert("Nama hanya boleh berisi huruf dan spasi.");
        return false;
    }
    if (!telpRegex.test(telp)) {
        alert("Nomor telepon hanya angka dan minimal 8 digit.");
        return false;
    }
    if (!email.includes("@") || !email.includes(".")) {
        alert("Format email tidak valid.");
        return false;
    }
    return true;
}
</script>

</head>
<body>

<div class="container">
    <h2>Tambah Kontak Baru</h2>

    <?php if ($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" name="form" onsubmit="return validateForm()">

        <label>Nama</label>
        <input type="text" name="nama" placeholder="Masukkan nama lengkap" required>

        <label>Nomor Telepon</label>
        <input type="text" name="telepon" placeholder="Masukkan nomor telepon" required>

        <label>Email</label>
        <input type="email" name="email" placeholder="Masukkan email" required>

        <button type="submit" name="save">Simpan Kontak</button>

        <a href="dashboard_kontak.php" class="back">← Kembali ke Dashboard</a>
    </form>
</div>

</body>
</html>
