<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];

if (!isset($_SESSION['kontak'][$id])) {
    die("Kontak tidak ditemukan.");
}

$kontak = $_SESSION['kontak'][$id];

if (isset($_POST['save'])) {

    $nama = trim($_POST['nama']);
    $telepon = trim($_POST['telepon']);
    $email = trim($_POST['email']);

    if (!preg_match("/^[a-zA-Z\s]+$/", $nama)) {
        $error = "Nama hanya boleh huruf dan spasi.";
    } elseif (!preg_match("/^[0-9]{8,15}$/", $telepon)) {
        $error = "Nomor telepon harus angka & minimal 8 digit.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid.";
    } else {
        $_SESSION['kontak'][$id] = [
            "nama" => $nama,
            "telepon" => $telepon,
            "email" => $email
        ];
        header("Location: dashboard_kontak.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Kontak</title>

<style>
    * {
        margin: 0; padding: 0; box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    body {
        background: #07121f;
        color: #e5f3ff;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px;
    }

    .container {
        width: 450px;
        background: rgba(20, 40, 70, 0.55);
        backdrop-filter: blur(10px);
        padding: 35px 40px;
        border-radius: 20px;
        border: 1px solid rgba(0, 150, 255, 0.3);
        box-shadow: 0 0 25px rgba(0,150,255,0.35);
        animation: fadeIn 0.5s ease;
    }

    h2 {
        text-align: center;
        margin-bottom: 25px;
        color: #76c8ff;
        text-shadow: 0 0 12px rgba(0,160,255,0.7);
    }

    .error {
        background: rgba(255, 60, 60, 0.25);
        border: 1px solid rgba(255, 80, 80, 0.5);
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 10px;
        color: #ff9f9f;
        text-align: center;
        font-size: 14px;
    }

    label {
        display: block;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 6px;
        color: #bfe6ff;
    }

    input {
        width: 100%;
        padding: 12px;
        border-radius: 12px;
        border: 1px solid rgba(90,170,255,0.4);
        background: rgba(255,255,255,0.07);
        color: #e9f4ff;
        font-size: 14px;
        margin-bottom: 18px;
        transition: 0.25s;
    }

    input:focus {
        border-color: #00baff;
        box-shadow: 0 0 12px rgba(0,160,255,0.9);
        outline: none;
    }

    button {
        width: 100%;
        padding: 12px;
        background: linear-gradient(135deg, #009dff, #00d0ff);
        border: none;
        color: white;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.25s;
        box-shadow: 0 0 18px rgba(0,160,255,0.5);
    }

    button:hover {
        box-shadow: 0 0 28px rgba(0,200,255,0.8);
        transform: translateY(-2px);
    }

    .back {
        display: block;
        margin-top: 20px;
        text-align: center;
        color: #8cd7ff;
        text-decoration: none;
        font-size: 14px;
        transition: 0.25s;
    }

    .back:hover {
        color: #baf0ff;
        text-shadow: 0 0 8px rgba(0,180,255,0.8);
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
</head>

<body>

<div class="container">

    <h2>Edit Kontak</h2>

    <?php if (!empty($error)): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Nama</label>
        <input type="text" name="nama" value="<?= $kontak['nama'] ?>" required>

        <label>Nomor Telepon</label>
        <input type="text" name="telepon" value="<?= $kontak['telepon'] ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?= $kontak['email'] ?>" required>

        <button type="submit" name="save">Simpan Perubahan</button>
        <a href="dashboard_kontak.php" class="back">← Kembali ke Dashboard</a>
    </form>

</div>

</body>
</html>
